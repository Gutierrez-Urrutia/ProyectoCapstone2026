"""Shared document rendering helpers."""
