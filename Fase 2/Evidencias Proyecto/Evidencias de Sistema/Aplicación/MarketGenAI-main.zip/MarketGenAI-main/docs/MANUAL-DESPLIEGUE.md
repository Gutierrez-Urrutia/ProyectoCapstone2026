# Manual de despliegue — MarketGen AI (NoonDalton AI Marketing Suite)

Cubre RNF-04 (Disponibilidad e integración), criterio 2: dependencias, variables de entorno y pasos para levantar la aplicación en local y en la nube.
El criterio 1 (qué ve el usuario cuando falla la IA, el CRM o la base de datos) está en la sección 6.
Si algo de aquí contradice al `README.md` raíz, vale este manual (el README describe una arquitectura anterior con Keycloak).

## 1. Qué se despliega

| Pieza | Tecnología | Dónde corre en dev |
|---|---|---|
| API | FastAPI (Python 3.12) | Cloud Run `marketgen-api` (`ROLE=api`) |
| Web | React 18 + Vite, servida por nginx | Cloud Run `marketgen-web` |
| Worker | Celery + Redis | VM `marketgen-worker` (se enciende solo cuando se necesita) |
| Base de datos | Firestore | `marketgen-dev` (`nam5`) |
| Archivos generados | Cloud Storage (URLs firmadas) | bucket `marketgen-dev-assets` |
| Secretos | Secret Manager | `marketgen-dev` |
| IA | DeepSeek (API externa) | — |

## 2. Dependencias

**Para trabajar en local**

| Herramienta | Versión | Para qué |
|---|---|---|
| Python | 3.12 | Backend |
| Node.js | 22 | Frontend |
| Git | cualquiera | Código |
| Docker | cualquiera | Redis local (opcional) y construir imágenes |
| Redis | 7 | Cola de Celery (opcional; ver §4) |
| Librerías de sistema (solo Linux/CI; el `backend/Dockerfile` ya las instala) | `libpango-1.0-0 libpangocairo-1.0-0 libpangoft2-1.0-0 libcairo2 libgdk-pixbuf-2.0-0` | WeasyPrint (PDF) |

**Para desplegar en la nube:** Google Cloud SDK (`gcloud`) con una cuenta con permisos sobre `marketgen-dev`.
En Windows, `gcloud.cmd` rompe argumentos con paréntesis o `|`: usar el Python que trae el SDK
(`platform\bundledpython\python.exe lib\gcloud.py`) o definir `GCLOUD` con la ruta a `gcloud.cmd` para los scripts de `infra/gcp/`.

Las dependencias de Python están fijadas en `backend/requirements.txt` y las de Node en `frontend/package-lock.json`. Versión de Python: 3.12 (`.python-version`: 3.12.7).

**Servicios externos que necesita:** DeepSeek (llave de API), Google OAuth (cliente OAuth, opcional si solo se usa correo y contraseña),
Microsoft Entra ID (opcional: login con Microsoft y buzón de envío), HubSpot o Salesforce (opcional, para enviar propuestas al CRM).

## 3. Variables de entorno

Se leen de `backend/.env` en local (plantilla: `backend/.env.example`) y de Cloud Run + Secret Manager en la nube.
**Nunca** se suben al repositorio: `.env` está ignorado por git.

### Backend — obligatorias

Con `APP_ENV=production` el arranque **se detiene** si falta alguna y el mensaje las lista **todas** de una vez, por ejemplo:
`Faltan variables de entorno obligatorias con APP_ENV=production: GOOGLE_CLOUD_PROJECT (proyecto de Firestore); DEEPSEEK_API_KEY (llave de la IA)`.
Fuera de producción solo se escribe un aviso en el log. Las credenciales de Firestore no se exigen porque en Cloud Run se usa la cuenta de servicio del servicio.

| Variable | Descripción | En la nube |
|---|---|---|
| `APP_ENV` | `development` o `production`. En `production` se exige una clave segura y se ocultan `/docs`, `/redoc` y `/openapi.json` | variable |
| `APP_SECRET_KEY` | Firma de los JWT. Larga y aleatoria (`python -c "import secrets; print(secrets.token_urlsafe(48))"`). Vacía o la de por defecto no arranca en producción | **secreto** `app-secret-key` |
| `GOOGLE_CLOUD_PROJECT` | Proyecto de Firestore (`marketgen-dev`) | variable |
| Credenciales de Firestore | En local: `GOOGLE_APPLICATION_CREDENTIALS` (ruta a JSON), `FIREBASE_CREDENTIALS_PATH` o `FIREBASE_SERVICE_ACCOUNT_JSON` (el JSON en una línea; si se define y no es un JSON válido, no arranca). En la nube se usa la cuenta de servicio del servicio, sin archivo. Cómo crearla: Google Cloud › IAM › Cuentas de servicio › rol «Cloud Datastore User» › Claves › JSON | **secreto** (el JSON) |
| `DEEPSEEK_API_KEY` | Llave de la IA | **secreto** `deepseek-api-key` |
| `PIPELINE_ENCRYPTION_KEY` | Llave Fernet que cifra las llaves de proveedores y tokens del buzón. **Local y dev comparten el mismo Firestore, así que deben usar la MISMA llave** (ver §7). Para local, copiar el valor del secreto de dev (`gcloud secrets versions access latest --secret=pipeline-encryption-key`) en `backend/.env`. Generar con `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"` | **secreto** `pipeline-encryption-key` |
| `STORAGE_BACKEND` | `gcs` en producción. El valor por defecto del código (`supabase`) ya no tiene un servicio detrás y **detiene el arranque en producción** | variable |
| `GCS_BUCKET` | Bucket de Cloud Storage de los archivos generados (obligatoria con `STORAGE_BACKEND=gcs`), p. ej. `marketgen-dev-assets` | variable |
| `BACKEND_CORS_ORIGINS` | Orígenes permitidos, separados por coma (la URL de la web) | variable |
| `FRONTEND_URL` | URL de la web (redirecciones del login con Google) | variable |

### Backend — según la funcionalidad

| Variable | Descripción | Valor habitual |
|---|---|---|
| `DEEPSEEK_BASE_URL`, `DEEPSEEK_MODEL` | Endpoint y modelo | `https://api.deepseek.com`, `deepseek-flash` |
| `LLM_SHORT_TIMEOUT_SECONDS`, `LLM_DEFAULT_TIMEOUT_SECONDS`, `LLM_LONG_TIMEOUT_SECONDS` | Tiempo máximo de cada llamada a la IA, en segundos. **Sin definir no hay límite y no existe «tiempo agotado»** (la sección 6 solo informa un timeout si está configurado): se recomienda fijarlos | sin definir |
| `GOOGLE_OAUTH_CLIENT_ID` / `GOOGLE_OAUTH_CLIENT_SECRET` | Login con Google | secreto `google-oauth-client-secret` |
| `MAIL_GOOGLE_REDIRECT_URL` | Redirección para conectar el Gmail del usuario (enviar correos). Misma app de Google que el login; registrar esta URI exacta en el cliente OAuth (ver §5.6) | local `http://127.0.0.1:8000/api/v1/mail-connection/google/callback`; dev: URL de Cloud Run + `/api/v1/mail-connection/google/callback` |
| `GOOGLE_REDIRECT_URI` | Debe coincidir **exacta** con la URI registrada en el cliente OAuth | local `http://127.0.0.1:8000/api/v1/auth/google/callback`; dev: URL de Cloud Run + `/api/v1/auth/google/callback` |
| `MICROSOFT_OAUTH_CLIENT_ID` / `MICROSOFT_OAUTH_CLIENT_SECRET` / `MICROSOFT_TENANT_ID` | Login con Microsoft (Entra ID, **inquilino único**: solo entran las cuentas de tu organización). Se piden juntas: con el ID de cliente, en producción son obligatorias el secreto y el ID del directorio (**GUID**, no el nombre). Es otra app de Entra ID que la del buzón de Outlook (`MAIL_OAUTH_*`). Ver §5.10 | secreto `microsoft-oauth-client-secret` |
| `MICROSOFT_REDIRECT_URI` | Debe coincidir **exacta** con la URI registrada en Entra ID. Vacía, el backend la arma con el host de la petición | local `http://localhost:8000/api/v1/auth/microsoft/callback`; dev: URL de Cloud Run + `/api/v1/auth/microsoft/callback` |
| `REDIS_URL`, `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND` | Cola de tareas largas | `redis://localhost:6379/0` y `/1` en local; secretos en la nube |
| `ROLE`, `CELERY_CONCURRENCY` | Qué proceso corre el contenedor (`all`, `api` o `worker`) y cuántas tareas hace el worker a la vez | `api` (Cloud Run), `worker` (VM); 2 |
| `OAUTH_REDIRECT_BASE_URL` | URL base de la API para las redirecciones OAuth | `http://127.0.0.1:8000/api/v1` en local |
| `TRUST_PROXY_HEADERS` | Usar el primer `X-Forwarded-For` como IP de la auditoría. Solo detrás de un proxy propio: cualquiera puede enviar esa cabecera | `false`; `true` en Render |
| `ADMIN_EMAILS` | Correos con rol admin además de los asignados en Firestore, separados por coma | vacío |
| `HUBSPOT_BASE_URL`, `SALESFORCE_API_VERSION` | Endpoint de HubSpot y versión de la API de Salesforce (las credenciales de cada usuario van cifradas en Firestore, no en variables) | `https://api.hubapi.com`, `v61.0` |
| `ACCESS_TOKEN_EXPIRE_MINUTES`, `REFRESH_TOKEN_EXPIRE_DAYS` | Duración de las sesiones | 30 y 14 |
| `LOCAL_DEV_AUTH_ENABLED`, `LOCAL_DEV_AUTH_EMAIL`, `LOCAL_DEV_AUTH_PASSWORD` | Cuenta de desarrollo con contraseña conocida (por defecto `admin123`). En la nube la contraseña es el secreto `local-dev-auth-password`. **`deploy_api.py` la deja encendida en dev; en una producción real hay que poner `LOCAL_DEV_AUTH_ENABLED=false`** | — |
| `RATE_LIMIT_ENABLED`, `AUDIT_LOG_ENABLED` | Límite de frecuencia y registro de auditoría | `true` |
| `MICROSOFT_OAUTH_*`, `MAIL_OAUTH_*` | Login con Microsoft y envío desde Outlook / Microsoft 365 (registro de app propio en Entra ID) | ver `.env.example` |
| `OUTREACH_REAL_SEND_ENABLED` | Interruptor general del envío real de correos de prospección, con Outlook o Gmail (apagado por defecto; además cada usuario lo enciende en Configuración) | `false` |
| `OUTREACH_REDIRECT_TO` | **Entorno de pruebas.** Si tiene valor (direcciones separadas por coma), TODO correo de prospección sale a esas direcciones y nunca al contacto real; si el valor es inválido no se envía nada. Es lo que distingue un ambiente de pruebas de uno real: en dev viene del **secreto** `outreach-redirect-to`, en local del `.env`. Vacío = se escribe a los contactos reales | secreto en dev; vacío solo en producción real |
| `META_*`, `LINKEDIN_ACCESS_TOKEN`, `TWITTER_*` | Publicación en redes sociales (integraciones parciales) | opcional |

Obsoletas (se pueden dejar vacías): `SUPABASE_*` (el proyecto configurado ya no existe), `GEMINI_*`/`GOOGLE_API_KEY` (proveedor de respaldo no usado), `VITE_KEYCLOAK_*`.

### Frontend

| Variable | Descripción |
|---|---|
| `VITE_API_URL` | URL base de la API, p. ej. `http://127.0.0.1:8000/api/v1` (plantilla: `frontend/.env.example`). **Se fija al compilar**: cambiarla exige reconstruir la imagen |
| `VITE_ENABLE_DEMO_LOGIN`, `VITE_SHOW_DEMO_BANNER` | Acceso y aviso de demostración |

## 4. Ejecución en local

```bash
# Backend (desde backend/)
python -m venv .venv
.venv/Scripts/pip install -r requirements.txt      # en Linux/Mac: .venv/bin/pip
cp .env.example .env                                # completar las variables obligatorias (§3)
.venv/Scripts/python -m uvicorn app.main:app --port 8000
# Documentación interactiva: http://127.0.0.1:8000/docs  (solo con APP_ENV=development)

# Frontend (desde frontend/)
npm install
npm run dev                                         # http://localhost:5173
```

- Entrar por `127.0.0.1` y no por `localhost` si se usa Google: esa es la URI registrada.
- **Redis y el worker son opcionales.** Sin ellos, la generación de propuestas corre dentro de la propia petición. Los libros y
  exportaciones largas sí necesitan el worker:
  ```bash
  docker run -d --name redis -p 6379:6379 redis:7
  celery -A app.workers.celery_app worker --loglevel=info -Q default,llm,exports --concurrency=2   # desde backend/
  ```
- Pruebas: `python -m pytest -q` (backend) y `npm test` (frontend). Las pruebas del backend usan un Firestore simulado y no llaman a la IA.
- Todo el stack con Docker: `docker compose up --build`.

### 4.1 Entorno limpio, paso a paso

Probado en un clon nuevo, con un entorno virtual vacío y **solo** lo que dice este manual:

1. Instalar las herramientas de la sección 2 (Python 3.12, Node 22; en Linux, las librerías de sistema).
2. `git clone` del repositorio.
3. Backend: `cd backend`, crear el entorno virtual e instalar `pip install -r requirements.txt`.
4. Crear la cuenta de servicio de Firestore (sección 3, fila «Credenciales de Firestore») y guardar el JSON fuera del repositorio.
5. Definir las variables **obligatorias** de la sección 3 (copiando `backend/.env.example` a `backend/.env`, o como variables de entorno). Sin ellas, con `APP_ENV=production`, el arranque se detiene y dice cuáles faltan.
6. Desplegar los índices de Firestore (una vez por proyecto): `firebase deploy --only firestore:indexes --project <id-del-proyecto>` (el `firebase.json` de la raíz apunta a `backend/firestore.indexes.json`). Sin ellos las consultas del registro de auditoría usan un camino lento.
7. Arrancar: `.venv/Scripts/python -m uvicorn app.main:app --port 8000` (en Linux/Mac, `.venv/bin/python`).
8. Comprobar: `GET /api/v1/health` responde `200` y `GET /api/v1/health/db` responde `200` con `"status":"ok"` (con la base de datos caída responde `503`).
9. Frontend: `cd frontend`, `cp .env.example .env`, `npm ci`, `npm run build` (o `npm run dev`).
10. Abrir la web, iniciar sesión y generar una propuesta.

## 5. Despliegue en Google Cloud (dev)

### 5.1 Automático (lo normal)

Cada push a `main` ejecuta `.github/workflows/deploy-dev.yml`: pruebas del backend y del frontend → construye y despliega la API →
despliega la web si cambió `frontend/` → reinicia el worker si está encendido → comprueba `GET /api/v1/health`.
Tarda ~8 minutos. GitHub se identifica con Workload Identity Federation (token temporal): no hay claves JSON en el repositorio.
Los cambios solo en `*.md`, `docs/` o `worker-vm.yml` no despliegan.

**Índices de Firestore.** Los índices compuestos del registro de auditoría están en `backend/firestore.indexes.json`. El despliegue
automático los aplica **solo cuando ese archivo cambia** (paso «Aplicar los índices de Firestore», que corre `infra/gcp/apply_indexes.py`):
los pide con `--async`, así que no suma tiempo (Firestore tarda unos 5 minutos en construirlos y mientras tanto la app usa su camino lento),
y si falla avisa sin tumbar el despliegue. Solo crea índices: si se borra uno del JSON hay que eliminarlo a mano en Firestore. Para aplicarlos
a mano: `python infra/gcp/apply_indexes.py` (repetible). Para forzarlo en CI: Actions › «Deploy dev (GCP)» › Run workflow. Requiere que
`marketgen-deployer` tenga `roles/datastore.indexAdmin` (lo asigna `setup_cicd.py`).

### 5.2 Primera vez (una sola vez, repetible)

Desde la raíz, con `gcloud` autenticado sobre `marketgen-dev`:

1. `python infra/gcp/load_secrets.py` — cuenta de servicio de la API y secretos en Secret Manager.
2. `python infra/gcp/setup_storage.py` — bucket de archivos, permisos y CORS.
3. `python infra/gcp/create_worker_vm.py` — VM del worker con Redis (IP interna fija `10.128.0.50`).
4. `python infra/gcp/setup_cicd.py main` — cuenta `marketgen-deployer` y la federación con GitHub (solo la rama `main`).
5. Primer despliegue de la API y la web (§5.3).

### 5.3 Manual (si el automático no está disponible)

```bash
# API (desde backend/)
gcloud builds submit . --tag=us-central1-docker.pkg.dev/marketgen-dev/marketgen/api:dev --project=marketgen-dev
python infra/gcp/deploy_api.py [orígenes CORS] [URL de la web]     # reemplaza TODAS las variables no secretas
# Web (desde frontend/)
gcloud builds submit . --config=cloudbuild.yaml --substitutions=_API_URL=https://<api>/api/v1 --project=marketgen-dev
gcloud run services update marketgen-web --image=us-central1-docker.pkg.dev/marketgen-dev/marketgen/web:dev --region=us-central1
```

Una imagen nueva con la **misma etiqueta `:dev`** no crea una revisión de Cloud Run por sí sola: cambiar algo, por ejemplo
`--update-env-vars=DEPLOYED_FROM=<commit>`.

### 5.4 Worker (VM)

- Encender, apagar o ver el estado: GitHub → Actions → **Worker VM (encender / apagar)** → Run workflow, o `python infra/gcp/vm.py start|stop|status`.
- Encendida cuesta ~US$0,02 por hora; apagada solo el disco. El arranque tarda ~1 minuto y descarga la imagen más reciente.
- Tras desplegar código nuevo, la VM debe reiniciarse para tomarlo (el despliegue automático lo hace si está encendida).
- Con la VM apagada la API sigue funcionando y la generación de propuestas corre en la propia petición.

### 5.5 Verificación posterior al despliegue

1. `curl https://<api>/api/v1/health` responde `200` y `curl https://<api>/api/v1/health/db` responde `200` (con la base de datos caída: `503`).
2. Sin sesión, `GET /api/v1/proposals` responde `403` y `/docs` responde `404`.
3. Abrir la web, iniciar sesión y generar una propuesta.
4. Si se usan libros o exportaciones: encender el worker y confirmar que el trabajo termina.

### 5.6 Enviar correos desde Gmail (quien entra con Google)

Cada usuario conecta su propio buzón en Configuración › Pipeline › Buzón de envío: **Conectar Outlook** o **Conectar Gmail**.
Gmail usa la misma app de Google del login (`GOOGLE_OAUTH_CLIENT_ID` / `GOOGLE_OAUTH_CLIENT_SECRET`), pide el permiso
`gmail.compose` (crear borradores y enviarlos; **no puede leer la bandeja**) y Outlook sigue funcionando igual. Para que
funcione en un ambiente hay que hacer, una vez:

1. **Activar la API de Gmail** en el proyecto de Google Cloud: `gcloud services enable gmail.googleapis.com --project=marketgen-dev`.
2. **Registrar la URI de redirección** en el cliente OAuth (Google Cloud › APIs y servicios › Credenciales › cliente web):
   `https://<api>/api/v1/mail-connection/google/callback` y, para local, `http://127.0.0.1:8000/api/v1/mail-connection/google/callback`.
3. **Fijar `MAIL_GOOGLE_REDIRECT_URL`** en el servicio: `gcloud run services update marketgen-api --update-env-vars=MAIL_GOOGLE_REDIRECT_URL=https://<api>/api/v1/mail-connection/google/callback`
   (`deploy_api.py` ya la incluye). Además deben estar `PIPELINE_ENCRYPTION_KEY` (cifra los tokens) y, para enviar de verdad, `OUTREACH_REAL_SEND_ENABLED=true`.
4. **Agregar el permiso a la pantalla de consentimiento** (Google Auth Platform › Acceso a los datos): `https://www.googleapis.com/auth/gmail.compose`.
   Mientras la app esté en modo «Prueba», solo conectan las cuentas de la lista de usuarios de prueba, y Google **vence el acceso a los 7 días**:
   la pantalla muestra «Hay que reconectar» y el usuario vuelve a conectar. Para uso general, Google exige verificar la app (`gmail.compose` es un permiso restringido).

Detalles que conviene saber: el usuario puede desmarcar el permiso de Gmail en la pantalla de Google (entonces no se conecta y se le dice por qué);
Google devuelve el código por la URL (`?code=`), pero es de un solo uso y sin el verificador PKCE, que solo conoce el servidor, no sirve;
Gmail no permite saber si un borrador desaparecido se envió o lo borró el usuario, así que si se pierde la respuesta del envío el correo queda
«incierto» y el usuario decide (marcar como enviado o reintentar); lo que se envía y recibe de Gmail se prueba con `tests/test_gmail_connection.py`.

### 5.7 Entornos de pruebas: los correos salen siempre al equipo

Para que ningún prospecto real reciba un correo de prueba, local y dev definen `OUTREACH_REDIRECT_TO` (§3):

- El correo se genera, aprueba y confirma como siempre con el contacto real, pero al enviarlo **el destinatario es la lista del secreto**
  (Gmail y Outlook). Asunto con prefijo `[PRUEBA]` y una primera línea que dice a quién iba dirigido. El historial guarda `redirected` y `delivered_to`.
- La confirmación de envío muestra «Se entregará a (pruebas)» con las direcciones. La lista de no contactar sigue protegiendo al contacto real.
- Si el valor existe pero no tiene direcciones válidas, el envío se detiene (`send_redirect_misconfigured`, 503) antes de reservar nada.
- Cambiar los destinatarios en dev: `printf '<a@x,b@y>' | gcloud secrets versions add outreach-redirect-to --data-file=- --project=marketgen-dev` y
  reiniciar la API (nueva revisión). **`deploy_api.py` monta este secreto: no quitarlo** o dev volvería a escribir a contactos reales.
- Las pruebas automáticas ignoran el valor del entorno (`conftest.py`), así que tenerlo en tu `.env` no las rompe.

### 5.8 Otros despliegues: Render y Vercel

- **Render:** `render.yaml` (raíz) declara el servicio `marketgen-backend` (`rootDir: backend`, `bash start.sh`, `healthCheckPath: /api/v1/health`, Python 3.12.7).
  Las variables obligatorias de la sección 3 están declaradas con `sync: false` (se cargan en el panel) salvo `APP_SECRET_KEY` (se genera) y `STORAGE_BACKEND`.
  El plan gratuito no instala librerías de sistema: los PDF con WeasyPrint necesitan una imagen Docker (`backend/Dockerfile`).
- **Vercel:** existe `api/index.py` (entrada serverless) pero no hay `vercel.json`: no es un destino mantenido. El destino de referencia es Cloud Run (sección 5).

### 5.9 Copias de seguridad

Los datos viven en Firestore. Exportación programada: `gcloud firestore export gs://<bucket-de-respaldos>/$(date +%F) --project=<id>` (requiere el rol `datastore.importExportAdmin`);
restauración: `gcloud firestore import gs://<bucket-de-respaldos>/<fecha> --project=<id>`. Los archivos generados están en el bucket `GCS_BUCKET`.

### 5.10 Login con Microsoft (Entra ID)

El botón «Continuar con Microsoft» deja entrar **solo a las cuentas del directorio (inquilino) de tu organización**: la autoridad es
`login.microsoftonline.com/<MICROSOFT_TENANT_ID>`, no `common`, y el backend vuelve a comprobar el directorio y la aplicación del token (`microsoft_wrong_tenant`).
Una cuenta personal o de otra organización no entra. El `state` y el verificador PKCE viajan en una cookie firmada de 10 minutos (`HttpOnly`, `SameSite=Lax`): si
falta, venció o no coincide, el login se rechaza (`microsoft_state_invalid`). Una cuenta inactiva (`status` distinto de `active`) o ligada a otra identidad de
Microsoft (`account_disabled`, `account_mismatch`) tampoco entra, igual que con Google.

Una sola vez por ambiente:

1. **Registrar la app** (portal de Azure › Microsoft Entra ID › Registros de aplicaciones › Nuevo registro): nombre «MarketGenAI login»;
   tipos de cuenta: **«Solo cuentas de este directorio de la organización (inquilino único)»**; plataforma **Web** con la URI de redirección
   `https://<api>/api/v1/auth/microsoft/callback` (y `http://localhost:8000/api/v1/auth/microsoft/callback` para local). Debe ser idéntica a `MICROSOFT_REDIRECT_URI`.
2. **Permisos de API** (delegados de Microsoft Graph): `openid`, `email`, `profile` y `User.Read`. No hace falta pedir consentimiento de administrador salvo que tu organización lo exija.
3. **Certificados y secretos › Nuevo secreto de cliente**: copiar el **Valor** (solo se muestra una vez) y anotar su vencimiento; al vencer, el login falla con `microsoft_token_failed` hasta renovarlo.
4. **Copiar** el «ID de aplicación (cliente)» y el «ID de directorio (inquilino)» de la página Información general.
5. **Guardar el secreto** en Secret Manager y dar acceso a la cuenta de servicio de la API (antes de desplegar, o `deploy_api.py` falla):
   `printf '%s' '<valor>' | gcloud secrets create microsoft-oauth-client-secret --data-file=- --project=marketgen-dev` y
   `gcloud secrets add-iam-policy-binding microsoft-oauth-client-secret --member=serviceAccount:marketgen-api@marketgen-dev.iam.gserviceaccount.com --role=roles/secretmanager.secretAccessor --project=marketgen-dev`.
6. **Configurar y desplegar**: poner `MICROSOFT_OAUTH_CLIENT_ID` y `MICROSOFT_TENANT_ID` en `backend/.env` y ejecutar `infra/gcp/deploy_api.py` (monta el secreto y fija
   `MICROSOFT_REDIRECT_URI`). Si cambia la URL de Cloud Run, actualizarla en Entra ID **y** en `deploy_api.py`.
7. **Verificar**: `GET /api/v1/auth/debug-urls` (solo admin) debe mostrar en `microsoft_callback` exactamente la URI registrada; después, entrar con una cuenta del directorio.

Opcional: en Entra ID › Aplicaciones empresariales › Propiedades, «Asignación requerida» = Sí limita el acceso a las personas o grupos que asignes.

## 6. Comportamiento ante fallas (RNF-04, criterio 1)

| Falla | Qué ve el usuario | La aplicación |
|---|---|---|
| IA sin conexión o con error del proveedor | 502 «El servicio de IA no está disponible en este momento. Inténtalo de nuevo en unos minutos.» | Sigue funcionando |
| IA lenta (timeout) | 504 «El servicio de IA tardó demasiado en responder. Inténtalo de nuevo.» | Sigue funcionando |
| La IA devuelve texto que no es el JSON esperado (análisis) | 502 «La IA devolvió una respuesta que no se pudo interpretar.» | Sigue funcionando |
| CRM: credenciales vencidas | 401 con el mensaje del CRM; no cierra la sesión | Sigue funcionando |
| CRM: timeout / caído / sin red | 504 / 502 con mensaje; el intento queda registrado en `crmSync` | Sigue funcionando |
| CRM: el proveedor responde con error | 502 «HubSpot respondió con error 500»; lo que devolvió el proveedor queda solo en el log del servidor | Sigue funcionando |
| Base de datos (Firestore) caída o sin cuota | 503 «La base de datos no está disponible en este momento…» (o «Se alcanzó el límite de uso…»), con cabeceras CORS | `/health` sigue en 200; `/health/db` responde 503 |
| Google Cloud Storage falla al subir, firmar o borrar un archivo | 503 «El almacenamiento de archivos no está disponible en este momento…» (con `code: storage_unavailable`); el detalle queda en el log | Sigue funcionando |
| Falta `PIPELINE_ENCRYPTION_KEY` al guardar una clave de proveedor | 503 «El servidor no tiene configurada la llave de cifrado… Avisa al administrador.» | Sigue funcionando |
| El inicio de sesión con Google, Microsoft o Facebook falla en el servidor | Aviso en el login: «No se pudo iniciar sesión con Google… Inténtalo de nuevo; si continúa, avisa al administrador.» | Sigue funcionando |
| Una tarea larga (job) falla | El job queda `failed` con un mensaje fijo y claro; el error real queda solo en el log | Sigue funcionando |
| El navegador no llega a la API | Aviso «No hay conexión con el servidor» y el sondeo de la tarea termina con un aviso | La pantalla no se bloquea |
| Redis o worker apagados | La propuesta se genera dentro de la petición, unos segundos más lenta | Sigue funcionando |
| Fallo al subir un archivo a Cloud Storage | Error visible (no un enlace roto) | Sigue funcionando |

Ningún mensaje de error incluye trazas, rutas del servidor, claves ni el cuerpo que devolvió el proveedor: el detalle va solo al log (`app/core/errors.py`).

Pruebas automáticas: `backend/tests/test_rnf05_disponibilidad.py` (IA), `test_proposals_crm.py` (CRM), `test_firestore_down.py` (base de datos), `test_error_safety.py` (mensajes sin detalles, almacenamiento y llave de cifrado) y `test_config_startup.py` (arranque y variables).

## 7. Problemas conocidos

| Síntoma | Causa y solución |
|---|---|
| El arranque termina con «Faltan variables de entorno obligatorias con APP_ENV=production: …» | Definir las variables que nombra el mensaje (sección 3) |
| `GET /api/v1/health/db` responde `503` | Firestore no responde: revisar el proyecto, la cuenta de servicio y la cuota (consola de Firebase › Uso). La API sigue viva (`/health` en 200) |
| `gcloud builds submit` falla con «forbidden … serviceusage.services.use» | Falta `storage.buckets.list`. `setup_cicd.py` crea el rol `bucketLister`; ejecutarlo de nuevo |
| El despliegue termina pero la API sigue con el código viejo | Misma etiqueta `:dev`: ver §5.3 (`DEPLOYED_FROM`) |
| El login con Google responde `redirect_uri_mismatch` | `GOOGLE_REDIRECT_URI` no coincide con la URI registrada en el cliente OAuth (§3) |
| El login con Microsoft muestra `AADSTS50011` (la URI de respuesta no coincide) | `MICROSOFT_REDIRECT_URI` (o la URL de Cloud Run) no es idéntica a la URI registrada en Entra ID › Autenticación (§5.10) |
| El login con Microsoft muestra `AADSTS700016` o `AADSTS50020` | El ID de cliente o el del directorio no son los de la app, o la cuenta es de otra organización: revisar `MICROSOFT_OAUTH_CLIENT_ID` y `MICROSOFT_TENANT_ID` |
| Microsoft: «no pertenece a la organización autorizada» (`microsoft_wrong_tenant`) | La cuenta no es del directorio configurado: entrar con la cuenta de trabajo |
| Microsoft: «la sesión venció o no es válida» (`microsoft_state_invalid`) | Pasaron más de 10 minutos, se bloquearon las cookies o el callback se abrió en otro navegador: volver a pulsar el botón. **En local:** el front arranca el login en `127.0.0.1:8000` (por defecto) y Microsoft vuelve a `localhost:8000`; las cookies no se comparten entre ambos hosts. Poner `VITE_API_URL=http://localhost:8000/api/v1` en `frontend/.env.local`, reiniciar Vite y abrir `http://localhost:5173` |
| Microsoft: `microsoft_token_failed` en todos los intentos | El secreto de cliente venció o es incorrecto (§5.10, paso 3) |
| Google rechaza a un usuario | La app está en modo de prueba: agregarlo en Google Auth Platform → Público → Usuarios de prueba |
| «Hay que reconectar» el buzón justo después de conectarlo en otro ambiente (motivo `tokens_unreadable`) | Local y dev tienen `PIPELINE_ENCRYPTION_KEY` distintas y comparten Firestore: cada uno no puede descifrar los tokens que guardó el otro y marca la conexión como rota. Usar la misma llave en ambos (§3). Si ya quedó marcada: volver a cifrar los tokens con la llave común o reconectar el buzón |
| El correo llega con las líneas cortadas a ~65 caracteres | Un correo solo de texto plano viaja con saltos a ~76 columnas y algunos clientes lo muestran como líneas cortas. Desde `9d68c2b` el envío por Gmail incluye una parte HTML con párrafos reales (`gmail_client.html_body`) |
| Gmail: «Hay que reconectar» a la semana | La app de Google está en modo «Prueba» y el acceso vence a los 7 días: el usuario reconecta |
| Gmail: `mail_service_unavailable` al enviar | La API de Gmail no está activada en el proyecto (§5.6, paso 1) |
| Un libro o exportación larga no avanza | Probablemente el worker está apagado: encenderlo (§5.4) |
| En local, un archivo generado no se descarga en la web | Con `STORAGE_BACKEND=supabase` (el valor por defecto) y un Supabase inexistente cae al disco; usar `gcs`. En producción `supabase` detiene el arranque |

## 8. Costo aproximado (dev)

~US$1–3 al mes con la VM apagada; ~US$0,02 por hora con la VM encendida. La IA (DeepSeek) se factura aparte según el uso.
