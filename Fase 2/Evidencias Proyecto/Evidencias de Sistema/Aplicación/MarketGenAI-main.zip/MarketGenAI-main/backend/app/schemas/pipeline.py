"""Schemas for the prospecting pipeline configuration (Fase 1 — infra only).

Covers PipelineConfig + JobSource (Agente 1 input) and the PipelineRun shape
that will be written by the orchestrator in a later phase. Lead/Contact/
OutreachEmail schemas live in their own modules (lead.py, contact.py,
outreach_email.py).
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from app.core.pipeline_constants import OUTREACH_DAILY_SEND_LIMIT_DEFAULT, OUTREACH_DAILY_SEND_LIMIT_MAX


class SourceType(str, Enum):
    API = "api"
    RSS = "rss"
    SCRAPER = "scraper"
    WEBHOOK = "webhook"
    JSEARCH = "jsearch"


# Fields each source_type needs in `JobSource.config` for /sources/{id}/test
# to consider the source "ready to run". Enforced at the API boundary only —
# no external calls are made yet (that's Fase 2, JobScoutService).
SOURCE_TYPE_REQUIRED_CONFIG_FIELDS: Dict[SourceType, List[str]] = {
    SourceType.API: ["base_url", "api_key"],
    SourceType.RSS: ["feed_url"],
    SourceType.SCRAPER: ["url", "selectors"],
    SourceType.WEBHOOK: [],
    SourceType.JSEARCH: ["api_key"],
}

# Config fields that hold secrets (API keys, tokens) and must be encrypted at
# rest with app.services.encryption_service before being persisted, same
# treatment as PipelineConfig.hunter_api_key. Never returned in plaintext by
# the API — see routers/pipeline.py `_split_source_config` / `_public_source`.
SOURCE_TYPE_SECRET_CONFIG_FIELDS: Dict[SourceType, List[str]] = {
    SourceType.API: ["api_key"],
    SourceType.RSS: [],
    SourceType.SCRAPER: [],
    SourceType.WEBHOOK: [],
    SourceType.JSEARCH: ["api_key"],
}

# The `config` field that holds the URL a source fetches from, per
# source_type. Validated for SSRF safety (app.core.url_safety) both at
# save time (routers/pipeline.py) and at fetch time (job_scout_service.py).
# WEBHOOK has none — it's push, this system never initiates a request to it.
# JSEARCH has none either: its endpoint is fixed in code
# (pipeline_constants.JSEARCH_SEARCH_URL), never taken from the user.
SOURCE_TYPE_URL_FIELDS: Dict[SourceType, Optional[str]] = {
    SourceType.API: "base_url",
    SourceType.RSS: "feed_url",
    SourceType.SCRAPER: "url",
    SourceType.WEBHOOK: None,
    SourceType.JSEARCH: None,
}

# How an RSS source's entry titles are split into (job_title, company),
# chosen per source in `JobSource.config["title_format"]`. A source that
# doesn't set it gets RSS_TITLE_FORMAT_NONE, which never splits — there is
# no global guess, each feed's format has to be declared explicitly.
RSS_TITLE_FORMAT_NONE = "none"
RSS_TITLE_FORMAT_COMPANY_COLON_TITLE = "company_colon_title"  # "Company: Job Title" (weworkremotely.com)
RSS_TITLE_FORMAT_TITLE_DASH_COMPANY = "title_dash_company"  # "Job Title - Company", split on the LAST " - "
RSS_TITLE_FORMATS = (RSS_TITLE_FORMAT_NONE, RSS_TITLE_FORMAT_COMPANY_COLON_TITLE, RSS_TITLE_FORMAT_TITLE_DASH_COMPANY)


class JobSource(BaseModel):
    id: str
    name: str
    source_type: SourceType
    enabled: bool = True
    config: Dict[str, Any] = Field(default_factory=dict)
    rate_limit: Optional[int] = None
    last_fetched_at: Optional[datetime] = None


class JobSourceCreate(BaseModel):
    name: str = Field(..., min_length=1)
    source_type: SourceType
    enabled: bool = True
    config: Dict[str, Any] = Field(default_factory=dict)
    rate_limit: Optional[int] = Field(None, ge=1)


class JobSourceUpdate(BaseModel):
    name: Optional[str] = None
    source_type: Optional[SourceType] = None
    enabled: Optional[bool] = None
    config: Optional[Dict[str, Any]] = None
    rate_limit: Optional[int] = Field(None, ge=1)


class PipelineConfig(BaseModel):
    id: str
    user_id: str
    keywords: List[str] = Field(default_factory=list)
    industries: List[str] = Field(default_factory=list)
    excluded_companies: List[str] = Field(default_factory=list)
    sources: List[JobSource] = Field(default_factory=list)

    # Real sending of prospecting emails (RF-VTA-16): the user's switch (off by
    # default) and daily cap. Sending also needs the server's master switch
    # (OUTREACH_REAL_SEND_ENABLED), reported read-only here, and a connected
    # mailbox (schemas/mail_connection.py).
    outreach_real_send_enabled: bool = False
    outreach_real_send_server_enabled: bool = False
    outreach_daily_send_limit: int = Field(OUTREACH_DAILY_SEND_LIMIT_DEFAULT, ge=1, le=OUTREACH_DAILY_SEND_LIMIT_MAX)

    # Hunter.io API key (Agente 2): stored encrypted as
    # hunter_api_key_encrypted, never returned by the API.
    hunter_api_key_configured: bool = False

    # Not shown in the UI and not used yet: kept for the scheduled scan of
    # RF-VTA-17 (deferred).
    scan_frequency_hours: int = Field(24, ge=1)
    # Same: no control in the UI (the on/off toggle was removed, it had no
    # effect) and nothing reads it; kept for RF-VTA-17. Warning for RF-VTA-17:
    # users who switched the old toggle off still have is_active=False stored,
    # so honouring it as-is would silently skip their scheduled scans — show
    # the control again or reset the value when that feature is built.
    is_active: bool = True

    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class PipelineConfigUpdate(BaseModel):
    """PUT /pipeline/config — partial update, hunter_api_key write-only.
    Fields not listed here (e.g. the retired SMTP settings) are ignored."""

    keywords: Optional[List[str]] = None
    industries: Optional[List[str]] = None
    excluded_companies: Optional[List[str]] = None

    outreach_real_send_enabled: Optional[bool] = None
    outreach_daily_send_limit: Optional[int] = Field(None, ge=1, le=OUTREACH_DAILY_SEND_LIMIT_MAX)

    # Not stripped here: routers/pipeline.py strips it, and tells a
    # whitespace-only value ("unchanged") from "" ("clear").
    hunter_api_key: Optional[str] = None

    # Kept for RF-VTA-17 (scheduled scan); no UI field sends it today.
    scan_frequency_hours: Optional[int] = Field(None, ge=1)
    # Kept for RF-VTA-17 too; no UI control sends it today (see PipelineConfig).
    is_active: Optional[bool] = None


class PipelineKeywordsUpdate(BaseModel):
    keywords: List[str] = Field(default_factory=list)
    industries: List[str] = Field(default_factory=list)
    excluded_companies: List[str] = Field(default_factory=list)


class PipelineRunCreateRequest(BaseModel):
    """Payload for triggering a pipeline scan with optional sync execution."""
    sync: bool = False


class PipelineRunStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PipelineRun(BaseModel):
    id: str
    pipeline_config_id: str
    user_id: str
    status: PipelineRunStatus
    leads_found: int = 0
    leads_new: int = 0
    contacts_found: int = 0
    emails_generated: int = 0
    emails_auto_approved: int = 0
    emails_pending_review: int = 0
    emails_sent: int = 0
    started_at: datetime
    agent1_completed_at: Optional[datetime] = None
    agent2_completed_at: Optional[datetime] = None
    agent3_completed_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    errors: List[Dict[str, Any]] = Field(default_factory=list)
