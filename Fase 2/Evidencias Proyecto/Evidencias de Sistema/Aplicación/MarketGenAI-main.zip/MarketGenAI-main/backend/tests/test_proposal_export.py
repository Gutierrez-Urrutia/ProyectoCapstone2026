"""Exportación de propuestas a PDF/DOCX: texto real, idioma, total solo bajo la tabla de precios."""
from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from pypdf import PdfReader

from app.routers import proposals as pr
from app.workers.tasks.proposal_tasks import build_pricing_table_html
from tests.conftest import FAKE_USER_SUB

API = "/api/v1/proposals"

TEAM_TABLE = "<table><thead><tr><th>Rol</th><th>Cantidad</th></tr></thead><tbody><tr><td>Gestor</td><td>15</td></tr></tbody></table>"


def _bpo_html() -> str:
    pricing = build_pricing_table_html(
        [{"name": "Gestión de cobranza", "description": "Gestor/mes", "qty": 15, "unitPrice": 1250}], 18750, "es"
    )
    return (
        "<h1>Propuesta de Cobranza Telefónica</h1><p>Para Financiera Horizonte</p>"
        "<h2>Resumen Ejecutivo</h2><p>Recuperación de cartera morosa con gestores dedicados.</p>"
        f"<h2>Equipo y Organización del Trabajo</h2>{TEAM_TABLE}"
        f"<h2>Precios y Condiciones Comerciales</h2>{pricing}<ul><li>Facturación mensual</li></ul>"
        "<h2>Condiciones Generales</h2><ul><li>Confidencialidad</li></ul>"
    )


def _proposal(**over) -> dict:
    base = {
        "id": "p1", "userId": FAKE_USER_SUB, "title": "Propuesta", "clientName": "Financiera Horizonte",
        "language": "es", "totalAmount": 18750, "content": _bpo_html(),
        "template": "NoonDalton Standard Proposal",
        "structuredContent": {"contact": "María Fuentes", "client": "Financiera Horizonte",
                              "industry": "B2B Operations", "serviceLine": "NoonDalton Standard Proposal"},
    }
    base.update(over)
    return base


def _pdf_text(path) -> str:
    return "\n".join(page.extract_text() for page in PdfReader(str(path)).pages)


def test_pdf_has_real_selectable_text_in_spanish(tmp_path):
    proposal = _proposal()
    out = tmp_path / "p.pdf"
    pr._build_proposal_pdf(out, "Propuesta", proposal["content"], pr._proposal_cover_fields(proposal))
    text = _pdf_text(out)
    assert "Propuesta de Cobranza Telefónica" in text
    assert "Resumen Ejecutivo" in text and "Condiciones Generales" in text
    assert "FECHA DE EMISIÓN" in text and "VÁLIDA HASTA" in text
    assert "Página 1" in text
    assert "Aceptación" in text and "Firma" in text
    assert "NoonDalton Standard Proposal" not in text  # el nombre de plantilla no es dato del cliente
    assert "B2B Operations" not in text
    assert "AI Marketing Suite" not in text  # nombre interno del producto
    assert "Documento confidencial" in text
    assert "$18.750 USD" in text


def test_total_card_only_after_pricing_table(tmp_path):
    proposal = _proposal()
    out = tmp_path / "p.pdf"
    pr._build_proposal_pdf(out, "Propuesta", proposal["content"], pr._proposal_cover_fields(proposal))
    text = _pdf_text(out)
    assert text.count("Total de la propuesta") == 1  # la tabla de equipo no lleva total
    assert text.index("Gestor") < text.index("Total de la propuesta")


def test_legacy_table_without_class_still_gets_total(tmp_path):
    proposal = _proposal(content="<h2>Costos</h2>" + TEAM_TABLE)
    out = tmp_path / "p.pdf"
    pr._build_proposal_pdf(out, "P", proposal["content"], pr._proposal_cover_fields(proposal))
    assert "Total de la propuesta" in _pdf_text(out)


def test_split_accepts_frontend_presentation_html():
    wrapped = (
        '<article class="proposal-preview-document"><div class="proposal-paper">'
        '<header class="proposal-cover"><h1>Mi Propuesta</h1><p class="proposal-subtitle">Para ACME</p></header>'
        "<section><h2>Resumen Ejecutivo</h2><p>Texto.</p></section>"
        '<section><h2>Riesgos</h2><div class="proposal-card-list">'
        '<div class="proposal-detail-card"><strong>Mora alta</strong><p>Impacta caja.</p></div></div></section>'
        '<div class="proposal-total-card"><span>Total</span></div>'
        '<section class="proposal-acceptance"><h2>Aceptación</h2></section>'
        "</div></article>"
    )
    title, subtitle, tags = pr._split_proposal_content(wrapped)
    assert title == "Mi Propuesta" and subtitle == "Para ACME"
    texts = [t.get_text(" ", strip=True) for t in tags]
    assert texts == ["Resumen Ejecutivo", "Texto.", "Riesgos", "Mora alta: Impacta caja."]


def test_docx_export_localized(tmp_path):
    from docx import Document
    proposal = _proposal(language="pt")
    out = tmp_path / "p.docx"
    pr._build_proposal_docx(out, "Proposta", proposal["content"], pr._proposal_cover_fields(proposal))
    doc = Document(str(out))
    text = "\n".join(p.text for p in doc.paragraphs) + "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    assert "DATA DE EMISSÃO" in text and "Aceitação" in text and "Total da proposta" in text
    footer = "\n".join(p.text for p in doc.sections[0].footer.paragraphs)
    assert "Documento confidencial" in footer and "Página" in footer
    assert "PAGE" in doc.sections[0].footer._element.xml  # campo de número de página


@pytest.mark.asyncio
async def test_export_endpoint_uses_edited_content_and_returns_pdf(client, tmp_path):
    edited = "<h1>Título Editado</h1><h2>Resumen Ejecutivo</h2><p>Texto editado por el usuario.</p>"
    with (
        patch("app.routers.proposals.proposals_repo.get", new_callable=AsyncMock, return_value=_proposal()),
        patch("app.routers.proposals._output_dir", return_value=tmp_path),
    ):
        resp = await client.post(f"{API}/p1/export", json={"format": "pdf", "content": edited, "issuedBy": "Admin User"})
    assert resp.status_code == 200 and resp.headers["content-type"] == "application/pdf"
    out = tmp_path / "out.pdf"
    out.write_bytes(resp.content)
    text = _pdf_text(out)
    assert "Texto editado por el usuario." in text and "Admin User" in text


@pytest.mark.asyncio
async def test_export_endpoint_rejects_other_users_proposal(client):
    with patch("app.routers.proposals.proposals_repo.get", new_callable=AsyncMock, return_value=_proposal(userId="otro")):
        resp = await client.post(f"{API}/p1/export", json={"format": "pdf"})
    assert resp.status_code == 403


def test_pdf_cover_has_brand_logo_and_label(tmp_path):
    proposal = _proposal()
    out = tmp_path / "p.pdf"
    pr._build_proposal_pdf(out, "Propuesta", proposal["content"], pr._proposal_cover_fields(proposal))
    first = PdfReader(str(out)).pages[0]
    assert len(first.images) == 1  # logo de la banda de portada
    assert "PROPUESTA COMERCIAL" in first.extract_text()


def test_docx_cover_has_brand_logo_and_primary_band(tmp_path):
    from docx import Document
    from app.rendering import proposal_brand
    proposal = _proposal()
    out = tmp_path / "p.docx"
    pr._build_proposal_docx(out, "Propuesta", proposal["content"], pr._proposal_cover_fields(proposal))
    doc = Document(str(out))
    assert len(doc.inline_shapes) == 1
    assert proposal_brand.PRIMARY.lstrip("#") in doc.tables[0]._tbl.xml  # banda de color primario


def test_brand_assets_exist():
    from app.rendering import proposal_brand
    assert proposal_brand.logo_available()
    assert proposal_brand.PRIMARY == "#225258" and proposal_brand.ACCENT == "#FF5500"


def test_cover_has_reference_number_in_pdf_and_docx(tmp_path):
    from docx import Document

    proposal = _proposal(id="ab12cd", createdAt="2026-10-17T10:00:00Z")
    cover = pr._proposal_cover_fields(proposal)
    assert cover["reference"] == "NDP-20261017-AB12"

    pdf = tmp_path / "p.pdf"
    pr._build_proposal_pdf(pdf, "Propuesta", proposal["content"], cover)
    assert "REFERENCIA: NDP-20261017-AB12" in _pdf_text(pdf)

    docx = tmp_path / "p.docx"
    pr._build_proposal_docx(docx, "Propuesta", proposal["content"], cover)
    assert "REFERENCIA: NDP-20261017-AB12" in " | ".join(p.text for p in Document(str(docx)).paragraphs)


def test_reference_label_is_localized():
    assert pr._proposal_cover_fields(_proposal(language="en"))["labels"]["reference"] == "REFERENCE"
    assert pr._proposal_cover_fields(_proposal(language="pt"))["labels"]["reference"] == "REFERÊNCIA"


@pytest.mark.asyncio
async def test_export_defaults_executive_to_current_user(client, tmp_path):
    with (
        patch("app.routers.proposals.proposals_repo.get", new_callable=AsyncMock, return_value=_proposal()),
        patch("app.routers.proposals._output_dir", return_value=tmp_path),
    ):
        resp = await client.post(f"{API}/p1/export", json={"format": "pdf"})
    assert resp.status_code == 200
    out = tmp_path / "out.pdf"
    out.write_bytes(resp.content)
    assert "PREPARADO POR" in _pdf_text(out) and "—" not in _pdf_text(out).split("PREPARADO POR")[1][:40]


def _html_con_condiciones_de_plantilla(language: str = "es") -> tuple[str, list[str]]:
    """Propuesta con el bloque de condiciones de la plantilla inyectado como lo hace el worker (RNF-03)."""
    from app.services.template_service import default_commercial_terms, render_placeholders
    from app.workers.tasks.proposal_tasks import COMMERCIAL_TERMS_MARKER, inject_commercial_terms

    texto, _ = render_placeholders(default_commercial_terms(language), {"valida_hasta": "30-11-2026", "monto_total": "$18.750 USD"})
    html = inject_commercial_terms(
        "<h1>Propuesta</h1><h2>Resumen Ejecutivo</h2><p>Hola.</p>"
        f"<h2>Precios y Condiciones Comerciales</h2><p>{COMMERCIAL_TERMS_MARKER}</p>"
        "<h2>Condiciones Generales</h2><ul><li>Confidencialidad</li></ul>",
        texto,
    )
    return html, [linea for linea in texto.splitlines() if linea.strip()]


def test_RNF03_las_condiciones_comerciales_de_la_plantilla_salen_en_el_pdf(tmp_path):
    html, lineas = _html_con_condiciones_de_plantilla()
    out = tmp_path / "p.pdf"
    pr._build_proposal_pdf(out, "Propuesta", html, pr._proposal_cover_fields(_proposal(content=html)))
    plano = " ".join(_pdf_text(out).split())
    for linea in lineas:
        assert " ".join(linea.split()) in plano, linea
    assert "{valida_hasta}" not in plano and "{monto_total}" not in plano   # las variables salen reemplazadas


def test_RNF03_las_condiciones_comerciales_de_la_plantilla_salen_en_el_docx(tmp_path):
    from docx import Document

    html, lineas = _html_con_condiciones_de_plantilla()
    out = tmp_path / "p.docx"
    pr._build_proposal_docx(out, "Propuesta", html, pr._proposal_cover_fields(_proposal(content=html)))
    doc = Document(str(out))
    plano = " ".join(" ".join(p.text for p in doc.paragraphs).split())
    for linea in lineas:
        assert " ".join(linea.split()) in plano, linea
