"""
RAG de propuestas históricas (RF-VTA-01).

La empresa carga sus propuestas (PDF, Word, CSV, Excel) como "base de conocimiento".
Cada archivo se fragmenta y se guarda en Firestore; al generar una propuesta se
recuperan los fragmentos más relevantes para el cliente y el servicio pedidos.

La recuperación es léxica (TF-IDF simplificado sobre los fragmentos del usuario),
sin dependencia de un servicio de embeddings.
"""
from __future__ import annotations

import asyncio
import math
import re
import unicodedata
from collections import Counter
from typing import Any

from app.services.document_text_service import extract_text
from app.services.firestore_service import (
    knowledge_chunks_repo,
    knowledge_documents_repo,
    new_id,
)

CHUNK_SIZE = 1200
CHUNK_OVERLAP = 150
MAX_CHUNKS_PER_DOC = 400
MAX_DOCS_PER_USER = 200
# RF-VTA-01 (CP-004): relevancia mínima. Un solo término genérico en común («24x7», «monitoreo») bastaba para
# meter fragmentos de otro rubro en el contexto. Se exige que el mejor fragmento cubra al menos esta fracción
# del peso (idf) de los términos de la consulta; si no, no hay contexto histórico para ese servicio. Solo la aplica el
# camino de las propuestas (get_rag_context_and_sources); rank_chunks y retrieve_sources la dejan apagada por defecto
# (la búsqueda de Sales enablement usa consultas ampliadas con sinónimos, donde coinciden pocos términos).
MIN_QUERY_COVERAGE = 0.30
# Con pocos fragmentos el idf se distorsiona (un término ausente pesa casi lo mismo que uno presente): para la cobertura
# se calcula como si hubiera al menos estos fragmentos.
COVERAGE_MIN_CORPUS = 20
# Con la regla activa, un fragmento solo entra si alcanza esta fracción de la cobertura del mejor: junto al fragmento que
# sí trata el servicio no se cuelan otros que comparten solo un par de términos (CP-004, control de cobranza).
RELATIVE_COVERAGE_FLOOR = 0.4
TOP_K = 5
MAX_CONTEXT_CHARS = 6000
_MAX_CHUNKS_SCANNED = 5000

_STOPWORDS = frozenset(
    "de la el en y a los las del un una por con para que se su al lo como mas o es "
    "the of and to in for with on is are an be by from this that or at as it".split()
)


def _tokens(text: str) -> list[str]:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    return [t for t in re.findall(r"[a-z0-9]{3,}", text) if t not in _STOPWORDS]


def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Agrupa párrafos hasta ~size caracteres; los párrafos enormes se parten con solape."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: list[str] = []
    current = ""
    for para in paragraphs:
        while len(para) > size:
            if current:
                chunks.append(current)
                current = ""
            chunks.append(para[:size])
            para = para[size - overlap:]
        if current and len(current) + len(para) + 2 > size:
            chunks.append(current)
            # el último fragmento arrastra un solape para no perder contexto
            current = current[-overlap:] + "\n\n" + para if overlap else para
        else:
            current = f"{current}\n\n{para}" if current else para
    if current:
        chunks.append(current)
    return chunks[:MAX_CHUNKS_PER_DOC]


# ── Ingesta ───────────────────────────────────────────────────────────────────
async def ingest_document(
    *,
    user_id: str,
    filename: str,
    data: bytes,
    title: str | None = None,
    service: str | None = None,
    client: str | None = None,
) -> dict[str, Any]:
    """Extrae, fragmenta e indexa un archivo. Lanza DocumentExtractionError si no es válido.

    La base de conocimiento es de la empresa: el documento lo ven y lo usan todos los usuarios.
    `user_id` queda solo como quien lo subió (trazabilidad)."""
    existing = await knowledge_documents_repo.list(limit=MAX_DOCS_PER_USER + 1)
    if len(existing) >= MAX_DOCS_PER_USER:
        raise ValueError(f"Máximo de {MAX_DOCS_PER_USER} documentos alcanzado; elimina alguno.")

    # La extracción es CPU-bound (PDF/Excel grandes): fuera del event loop.
    text, ext = await asyncio.to_thread(extract_text, filename, data)
    chunks = chunk_text(text)

    doc = await knowledge_documents_repo.create({
        "userId": user_id,
        "filename": filename,
        "title": (title or "").strip() or filename,
        "service": (service or "").strip(),
        "client": (client or "").strip(),
        "fileType": ext.lstrip("."),
        "sizeBytes": len(data),
        "charCount": len(text),
        "chunkCount": len(chunks),
        "status": "ready",
    })
    for i in range(0, len(chunks), 50):
        await asyncio.gather(*(
            knowledge_chunks_repo.create({
                "docId": doc["id"],
                "userId": user_id,
                "index": n,
                "text": chunk,
                "tokens": _tokens(chunk),
            }, doc_id=new_id())
            for n, chunk in enumerate(chunks[i:i + 50], start=i)
        ))
    return doc


async def delete_document(doc_id: str) -> None:
    chunks = await knowledge_chunks_repo.list(
        filters=[("docId", "==", doc_id)], limit=MAX_CHUNKS_PER_DOC + 1
    )
    await asyncio.gather(*(knowledge_chunks_repo.delete(c["id"]) for c in chunks))
    await knowledge_documents_repo.delete(doc_id)


# ── Recuperación ──────────────────────────────────────────────────────────────
def rank_chunks(
    query: str,
    chunks: list[dict[str, Any]],
    docs_by_id: dict[str, dict[str, Any]],
    *,
    client_name: str = "",
    top_k: int = TOP_K,
    min_coverage: float = 0.0,
    focus_query: str = "",
) -> list[dict[str, Any]]:
    """Ordena fragmentos por relevancia; devuelve [] si ninguno comparte términos con la consulta o si el mejor
    cubre menos de `min_coverage` del peso de los términos del servicio (0 desactiva la regla).
    `focus_query` es lo que se pide (título y descripción); la cobertura se mide sobre sus términos para que el texto
    largo de detalle de la oportunidad no la diluya. Sin él, se mide sobre toda la consulta."""
    q_terms = set(_tokens(query))
    if not q_terms or not chunks:
        return []

    n = len(chunks)
    focus_terms = set(_tokens(focus_query)) if focus_query else q_terms
    df: Counter[str] = Counter()
    for c in chunks:
        df.update(set(c.get("tokens") or []) & (q_terms | focus_terms))
    idf = {t: math.log(1 + n / (1 + df[t])) for t in q_terms}

    service_terms = q_terms
    client_terms = set(_tokens(client_name))
    # La cobertura mide qué tanto trata el fragmento el SERVICIO pedido: el nombre del cliente casi nunca está en los
    # documentos históricos y no debe restarle relevancia.
    cov_terms = (focus_terms - set(_tokens(client_name))) or focus_terms
    cov_idf = {t: math.log(1 + max(n, COVERAGE_MIN_CORPUS) / (1 + df[t])) for t in cov_terms}
    idf_total = sum(cov_idf.values())
    best_coverage = 0.0
    scored = []
    for c in chunks:
        toks = c.get("tokens") or []
        if not toks:
            continue
        tf = Counter(toks)
        score = sum(idf[t] * (1 + math.log(tf[t])) for t in q_terms if t in tf)
        if score <= 0:
            continue
        coverage = sum(cov_idf[t] for t in cov_terms if t in tf) / idf_total if idf_total else 0.0
        best_coverage = max(best_coverage, coverage)
        score /= math.sqrt(len(toks))

        doc = docs_by_id.get(c.get("docId"), {})
        # Los metadatos del documento pesan: el contexto "depende del cliente y del servicio".
        if service_terms & set(_tokens(f"{doc.get('service', '')} {doc.get('title', '')}")):
            score *= 1.5
        if client_terms and client_terms & set(_tokens(doc.get("client", ""))):
            score *= 1.3
        scored.append((score, c, coverage))

    if best_coverage < min_coverage:
        return []  # ningún fragmento trata realmente lo que se pide
    if min_coverage > 0:
        scored = [x for x in scored if x[2] >= RELATIVE_COVERAGE_FLOOR * best_coverage]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c, _ in scored[:top_k]]


async def retrieve_sources(
    user_id: str | None,
    client_name: str = "",
    service_type: str = "",
    extra_query: str = "",
    min_coverage: float = 0.0,
) -> list[dict[str, str]]:
    """Fragmentos más relevantes de la base de conocimiento de la empresa como [{docId, title, text}],
    dentro del presupuesto de caracteres. Lista vacía si no hay documentos relevantes.

    Los documentos son compartidos por todos los usuarios; `user_id` solo exige una sesión válida."""
    if not user_id:
        return []
    docs = await knowledge_documents_repo.list(limit=MAX_DOCS_PER_USER)
    if not docs:
        return []
    chunks = await knowledge_chunks_repo.list(limit=_MAX_CHUNKS_SCANNED)
    docs_by_id = {d["id"]: d for d in docs}
    query = " ".join(filter(None, [service_type, extra_query, client_name]))
    top = rank_chunks(query, chunks, docs_by_id, client_name=client_name, min_coverage=min_coverage, focus_query=service_type)

    sources, used = [], 0
    for c in top:
        title = docs_by_id.get(c["docId"], {}).get("title", "documento")
        if used + len(title) + len(c["text"]) > MAX_CONTEXT_CHARS:
            break
        sources.append({"docId": c["docId"], "title": title, "text": c["text"]})
        used += len(title) + len(c["text"])
    return sources


def unique_source_refs(sources: list[dict[str, str]]) -> list[dict[str, str]]:
    """Documentos distintos usados como fuente, como [{docId, title}] (sin el texto)."""
    seen: set[str] = set()
    refs = []
    for s in sources:
        if s["docId"] not in seen:
            seen.add(s["docId"])
            refs.append({"docId": s["docId"], "title": s["title"]})
    return refs


async def get_rag_context(
    user_id: str | None,
    client_name: str = "",
    service_type: str = "",
    extra_query: str = "",
) -> str:
    """Contexto para el prompt de generación; cadena vacía si el usuario no cargó documentos
    relevantes (no se inventa un contexto de relleno)."""
    context, _ = await get_rag_context_and_sources(user_id, client_name, service_type, extra_query)
    return context


async def get_rag_context_and_sources(
    user_id: str | None,
    client_name: str = "",
    service_type: str = "",
    extra_query: str = "",
) -> tuple[str, list[dict[str, str]]]:
    """Como get_rag_context, pero devuelve además los documentos usados (para mostrarlos al usuario)."""
    # Propuestas (RF-VTA-01): solo hay contexto histórico si algún fragmento trata realmente el servicio pedido (CP-004).
    sources = await retrieve_sources(user_id, client_name, service_type, extra_query, min_coverage=MIN_QUERY_COVERAGE)
    if not sources:
        return "", []
    blocks = [f"[Fuente: {s['title']}]\n{s['text']}" for s in sources]
    return (
        "CONTEXTO DE PROPUESTAS HISTÓRICAS DE LA EMPRESA:\n"
        "Los siguientes extractos provienen de propuestas reales cargadas por la empresa. "
        "Úsalos como referencia de servicios, estilo, estructura y tono. No copies datos de "
        "otros clientes (nombres, precios, cifras) a esta propuesta.\n\n"
        + "\n\n---\n\n".join(blocks)
        + "\n"
    ), unique_source_refs(sources)
